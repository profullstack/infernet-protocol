export { PaymentManager, type CoinPayConfig } from './manager.js';
